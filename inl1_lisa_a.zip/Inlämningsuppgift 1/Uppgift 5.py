# Uppgift 5
# Print the area
# print(calculate_triangle_area(12, 8)) # => 48

# Store the height and width in variables
# then calculate the area and finally print it
# width = 12
# height = 8
# area = calculate_triangle_area(width, height)
# print(area)

def calculate_triangle_area(width, height):
    return width * height / 2
