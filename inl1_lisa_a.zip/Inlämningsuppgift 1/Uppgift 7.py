# Uppgift 7
# print(isEven(10)) # => True
# print(isEven(17)) # => False

def isEven(val):
    return val % 2 == 0
