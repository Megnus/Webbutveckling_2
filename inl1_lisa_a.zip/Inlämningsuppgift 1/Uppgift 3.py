# Uppgift 3
part_1 = "The area of a Triangle with a width of "
part_2 = 12
part_3 = " and a height of "
part_4 = 8
part_5 = " is: "
# Calculate the area with the variables part_2
# and part_4 (the area is: height * width / 2)
part_6 = part_2 * part_4 / 2

all_parts = part_1 + str(part_2) + part_3 + str(part_4) + part_5 + str(part_6)
print(all_parts)
