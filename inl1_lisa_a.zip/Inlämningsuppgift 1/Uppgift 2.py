# Uppgift 2
# The name
name = "Sherlock Holmes"
# Number of characters
num_of_chars = len(name)
# Print the number of characters
print(num_of_chars)
