# Uppgift 4

# Del 1
# Skriv ut "Tis" av "Tisdag"
# Skriv ut "burgare" av "Hamburgare"
# Skriv ut "be back" av "I'll be back"
tisdag = "Tisdag"
burgare = "Hamburgare"
illBeBack = "I'll be back"
print(tisdag[:3])
print(burgare[3:])
print(illBeBack[5:])

# Del 2
# Skriv ut "LEARNING" av "It's Learning"
# Skriv ut "good parts" av "Python: The Good Parts"
itsLearning = "It's Learning"
theGoodParts = "Python: The Good Parts"
print(itsLearning[5:].upper())
print(theGoodParts[12:].lower())

